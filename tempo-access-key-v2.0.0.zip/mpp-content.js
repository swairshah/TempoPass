"use strict";
(() => {
  // src/mpp-content.ts
  var EXTENSION_ID = "__TEMPO_MPP__";
  var script = document.createElement("script");
  script.src = chrome.runtime.getURL("mpp-inject.js");
  script.onload = () => script.remove();
  (document.head || document.documentElement).appendChild(script);
  window.addEventListener("message", async (event) => {
    if (event.source !== window) return;
    if (event.data?.type !== `${EXTENSION_ID}:challenge`) return;
    const { requestId, url, wwwAuthenticate, method } = event.data;
    try {
      const response = await chrome.runtime.sendMessage({
        type: "mpp:challenge",
        requestId,
        url,
        wwwAuthenticate,
        method
      });
      window.postMessage({
        type: `${EXTENSION_ID}:credential`,
        requestId,
        credential: response.credential,
        error: response.error
      }, "*");
    } catch (err) {
      window.postMessage({
        type: `${EXTENSION_ID}:credential`,
        requestId,
        error: err.message || "Extension communication failed"
      }, "*");
    }
  });
})();
//# sourceMappingURL=mpp-content.js.map
