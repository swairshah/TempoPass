"use strict";
(() => {
  // src/mpp-inject.ts
  var EXTENSION_ID = "__TEMPO_MPP__";
  var CACHE_PREFIX = "__mpp_cred:";
  var originalFetch = window.fetch.bind(window);
  var pendingPayments = /* @__PURE__ */ new Map();
  function cacheKey(url) {
    try {
      const u = new URL(url, location.origin);
      return CACHE_PREFIX + u.origin + u.pathname;
    } catch {
      return CACHE_PREFIX + url;
    }
  }
  function getCachedCredential(url) {
    try {
      return localStorage.getItem(cacheKey(url));
    } catch {
      return null;
    }
  }
  function setCachedCredential(url, credential) {
    try {
      localStorage.setItem(cacheKey(url), credential);
    } catch {
    }
  }
  function clearCachedCredential(url) {
    try {
      localStorage.removeItem(cacheKey(url));
    } catch {
    }
  }
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    if (event.data?.type !== `${EXTENSION_ID}:credential`) return;
    const { requestId, credential, error } = event.data;
    const pending = pendingPayments.get(requestId);
    if (!pending) return;
    pendingPayments.delete(requestId);
    if (error) {
      pending.reject(new Error(error));
    } else {
      pending.resolve(credential);
    }
  });
  window.fetch = async function mppFetch(input, init) {
    const url = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
    const cached = getCachedCredential(url);
    if (cached) {
      const headers = new Headers(init?.headers);
      if (!headers.has("Authorization")) {
        headers.set("Authorization", cached);
      }
      const cachedResponse = await originalFetch(input, { ...init, headers });
      if (cachedResponse.status !== 402) return cachedResponse;
      clearCachedCredential(url);
    }
    const response = await originalFetch(input, init);
    if (response.status !== 402) return response;
    const wwwAuth = response.headers.get("www-authenticate");
    if (!wwwAuth || !wwwAuth.startsWith("Payment ")) return response;
    const requestId = crypto.randomUUID();
    window.postMessage({
      type: `${EXTENSION_ID}:challenge`,
      requestId,
      url,
      wwwAuthenticate: wwwAuth,
      method: init?.method || "GET"
    }, "*");
    const credential = await new Promise((resolve, reject) => {
      pendingPayments.set(requestId, { resolve, reject });
      setTimeout(() => {
        if (pendingPayments.has(requestId)) {
          pendingPayments.delete(requestId);
          reject(new Error("Payment timeout"));
        }
      }, 6e4);
    });
    const retryInit = { ...init, headers: new Headers(init?.headers) };
    retryInit.headers.set("Authorization", credential);
    const paidResponse = await originalFetch(input, retryInit);
    if (paidResponse.ok) {
      setCachedCredential(url, credential);
    }
    return paidResponse;
  };
  console.log("[Tempo MPP] Payment-aware fetch active");
})();
//# sourceMappingURL=mpp-inject.js.map
